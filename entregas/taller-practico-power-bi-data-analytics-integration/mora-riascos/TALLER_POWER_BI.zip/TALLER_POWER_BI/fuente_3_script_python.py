# ==============================================================================
# TALLER POWER BI - FUENTE C (SCRIPT DE PYTHON)
# ==============================================================================

import pandas as pd
import numpy as np

# Ruta al archivo de canciones (o podés usar URL directa)
ruta_csv = '/home/nathalia/Descargas/taller analitica/fuente_1_spotify_canciones.csv'

try:
    df_base = pd.read_csv(ruta_csv)
except Exception:
    # Alternativa directa por si la ruta local difiere
    url = 'https://raw.githubusercontent.com/rfordatascience/tidytuesday/master/data/2020/2020-01-21/spotify_songs.csv'
    df_base = pd.read_csv(url)

# Generación analítica de la tabla complementaria de artistas (+1.000 registros)
tabla_artistas = df_base.groupby('track_artist').agg(
    total_canciones=('track_id', 'count'),
    popularidad_promedio=('track_popularity', 'mean'),
    energia_promedio=('energy', 'mean'),
    bailabilidad_promedio=('danceability', 'mean')
).reset_index()

# Filtramos artistas con al menos 2 canciones para tener un benchmark sólido (+1.500 artistas)
# o los 1.500 artistas con mayor presencia
tabla_artistas_benchmark = tabla_artistas.sort_values(by='total_canciones', ascending=False).head(1500).copy()

# Redondear métricas
tabla_artistas_benchmark['popularidad_promedio'] = tabla_artistas_benchmark['popularidad_promedio'].round(1)
tabla_artistas_benchmark['energia_promedio'] = tabla_artistas_benchmark['energia_promedio'].round(2)
tabla_artistas_benchmark['bailabilidad_promedio'] = tabla_artistas_benchmark['bailabilidad_promedio'].round(2)

# Clasificación calculada por Python
def clasificar_segmento(row):
    if row['popularidad_promedio'] >= 65 and row['total_canciones'] >= 5:
        return 'Top Global'
    elif row['popularidad_promedio'] >= 45:
        return 'Consolidado'
    else:
        return 'Emergente / Nicho'

tabla_artistas_benchmark['segmento_artista'] = tabla_artistas_benchmark.apply(clasificar_segmento, axis=1)

# Meta de streaming anual simulada (en millones) según su popularidad
tabla_artistas_benchmark['meta_reproducciones_millones'] = (
    tabla_artistas_benchmark['popularidad_promedio'] * 2.5 + tabla_artistas_benchmark['total_canciones'] * 1.2
).round(1)

# Guardar copia local de respaldo
if __name__ == '__main__':
    salida = '/home/nathalia/Descargas/taller analitica/fuente_3_resumen_artistas.csv'
    tabla_artistas_benchmark.to_csv(salida, index=False)
    print(f"Fuente 3 generada con éxito en: {salida}")
    print(f"Total filas: {len(tabla_artistas_benchmark)}")
    print(tabla_artistas_benchmark.head(5))
